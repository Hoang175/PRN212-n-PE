﻿using Question1;
using static Question1.Student;

StudentManager manager = new StudentManager();

Console.WriteLine("Enter the number of students to add:");
int numberOfStudents = int.Parse(Console.ReadLine());

for (int i = 0; i < numberOfStudents; i++)
{
    Console.WriteLine($"\nEnter details for student {i + 1}:");
    Student student = StudentManager.InputStudent();
    manager.AddStudent(student);
}

Console.WriteLine("\nList of all students:");
manager.DisplayStudents();

IsPromotable isPromotable = (Student student) => student.Age >= 18;

Console.WriteLine("\nPromotable students (Age >= 18):");
manager.PromoteStudents(isPromotable);