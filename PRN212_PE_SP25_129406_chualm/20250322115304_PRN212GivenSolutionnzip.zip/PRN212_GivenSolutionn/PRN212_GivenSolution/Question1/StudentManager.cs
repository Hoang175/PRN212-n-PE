﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Question1.Student;

namespace Question1
{
    public class StudentManager
    {

        private List<Student> students = new List<Student>();


        public void AddStudent(Student student)
        {
            students.Add(student);
        }

        public static Student InputStudent()
        {
            Console.WriteLine("Enter Student Id:");
            int id = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Student Name:");
            string name = Console.ReadLine();

            Console.WriteLine("Enter Student Age:");
            int age = int.Parse(Console.ReadLine());

            return new Student(id, name, age);
        }

        public void DisplayStudents()
        {
            if (students.Count == 0)
            {
                Console.WriteLine("No students in the list.");
                return;
            }

            foreach (var student in students)
            {
                student.Display();
            }
        }


        public void PromoteStudents(IsPromotable isPromotable)
        {
            Console.WriteLine("Promotable Students:");
            bool hasPromotableStudents = false;

            foreach (var student in students)
            {
                if (isPromotable(student))
                {
                    student.Display();
                    hasPromotableStudents = true;
                }
            }

            if (!hasPromotableStudents)
            {
                Console.WriteLine("No students meet the promotion criteria.");
            }
        }
    }
}
