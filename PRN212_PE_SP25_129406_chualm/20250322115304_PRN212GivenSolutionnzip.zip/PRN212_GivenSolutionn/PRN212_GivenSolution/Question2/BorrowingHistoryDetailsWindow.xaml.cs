﻿using Microsoft.EntityFrameworkCore;
using Question2.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Question2
{
    /// <summary>
    /// Interaction logic for BorrowingHistoryDetailsWindow.xaml
    /// </summary>
    public partial class BorrowingHistoryDetailsWindow : Window
    {
        private readonly int _bookId;
        private Book _book;
        private BookCopy _selectedCopy;
        public BorrowingHistoryDetailsWindow(int bookId)
        {
            InitializeComponent();
            _bookId = bookId;
            LoadBookDetails();
        }
        private void LoadBookDetails()
        {
            _book = LibraryManagementContext.INSTANCE.Books
                .Include(b => b.BookCopies)
                .ThenInclude(c => c.BorrowHistories)
                .ThenInclude(bh => bh.Borrower)
                .FirstOrDefault(b => b.BookId == _bookId);


                DataContext = this;
                CopiesDataGrid.ItemsSource = _book.BookCopies;
            
        }

        public Book Book => _book;

        private void CopiesDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CopiesDataGrid.SelectedItem is BookCopy selectedCopy)
            {
                _selectedCopy = selectedCopy;
                BorrowingHistoryDataGrid.ItemsSource = selectedCopy.BorrowHistories;
            }
        }

        private void ReturnButton_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedCopy == null)
            {
                MessageBox.Show("Please select a copy to return.", "No Copy Selected", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var activeBorrowing = _selectedCopy.BorrowHistories
                .FirstOrDefault(bh => bh.ReturnDate == null);

            if (activeBorrowing == null)
            {
                MessageBox.Show("Attempting to return a copy that is not currently borrowed.", "Invalid Operation", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            DateOnly dateOnly = DateOnly.FromDateTime(DateTime.Now);
            activeBorrowing.ReturnDate = DateOnly.FromDateTime(DateTime.Now);
            _selectedCopy.Status = "Available";
            LibraryManagementContext.INSTANCE.SaveChanges();

            // Refresh the UI
            LoadBookDetails();
            BorrowingHistoryDataGrid.ItemsSource = _selectedCopy.BorrowHistories;
        }
    }
}
