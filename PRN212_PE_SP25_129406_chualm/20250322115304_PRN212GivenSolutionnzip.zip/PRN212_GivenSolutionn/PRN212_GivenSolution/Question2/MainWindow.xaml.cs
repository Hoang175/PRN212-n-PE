﻿using Microsoft.EntityFrameworkCore;
using Question2.Model;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Question2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadData();
        }
        void LoadData()
        {
            BooksDataGrid.ItemsSource = LibraryManagementContext.INSTANCE.Books.Include(b => b.Genre).ToList();
        }
        private void ListSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //if (BooksDataGrid.SelectedItem is Book selectedBook)
            //{
            //    var detailsWindow = new BorrowingHistoryDetailsWindow(selectedBook.BookId);
            //    detailsWindow.ShowDialog();
            //}
            //else
            //{
            //    MessageBox.Show("", "No Book Selected", MessageBoxButton.OK, MessageBoxImage.Warning);
            //}
        }

        private void ViewBorrowersButton_Click(object sender, RoutedEventArgs e)
        {
            if (BooksDataGrid.SelectedItem is Book selectedBook)
            {
                var detailsWindow = new BorrowingHistoryDetailsWindow(selectedBook.BookId);
                detailsWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("No Book Selected", "No Book Selected", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}